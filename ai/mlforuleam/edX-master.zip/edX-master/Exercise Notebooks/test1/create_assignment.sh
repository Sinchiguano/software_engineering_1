nbgrader db assignment add $1
