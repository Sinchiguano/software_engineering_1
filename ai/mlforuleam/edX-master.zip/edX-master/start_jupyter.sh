JUPYTER_NO_CONFIG=1 jupyter notebook --ip=127.0.0.1
